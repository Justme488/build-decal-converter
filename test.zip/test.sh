#!/usr/bin/env bash

# Select input file
input_file=$(zenity --file-selection --filename="${HOME}/Desktop/" --title="Select the source decal")

# If the user selects the "cancel" button, close the script
if [[ "$?" = "1" ]]; then
  exit
fi

#make folder "test" to work in on desktop
mkdir "${HOME}/Desktop/test"

# Assign temp_dir variable
temp_dir="${HOME}/Desktop/test"

# Remove background, and make transparent
# Reassign basename of input_file with no extension 
input_file_no_path_or_ext=$(basename "${input_file%.*}")

# find background color of input image in png folder, and store in variable bg
bg=$(convert "$input_file" -format "%[hex:p{5,5}]" info:)

# Remove background for input image
convert "$input_file" -filter "lanczos" -fuzz "20%" -transparent "#${bg}" "${temp_dir}/${input_file_no_path_or_ext}_bg_removed.png"

# Trim Decal
convert -background "none" "${temp_dir}/${input_file_no_path_or_ext}_bg_removed.png" -filter "lanczos" -trim +repage -alpha set -bordercolor "transparent" -border "5x5" "${temp_dir}/${input_file_no_path_or_ext}_trimmed.png"

# get input image width
input_file_width=$(identify -format "%w" "${temp_dir}/${input_file_no_path_or_ext}_trimmed.png")

# get input image height
input_file_height=$(identify -format "%h" "${temp_dir}/${input_file_no_path_or_ext}_trimmed.png")

# Resize based on larger dimension
if [[ "$input_file_width" -ge "$input_file_height" ]]; then
  convert "${temp_dir}/${input_file_no_path_or_ext}_trimmed.png" -filter "lanczos" -resize "750x${input_file_height}" -background "transparent" -gravity "center" -extent "800x800" "${temp_dir}/${input_file_no_path_or_ext}_resized.png"
else
  convert "${temp_dir}/${input_file_no_path_or_ext}_trimmed.png" -filter "lanczos" -resize "${input_file_width}x750" -background "transparent" -gravity "center" -extent "800x800" "${temp_dir}/${input_file_no_path_or_ext}_resized.png"
fi

# Fill with black
convert "${temp_dir}/${input_file_no_path_or_ext}_resized.png" -filter "lanczos" -fill "#000000" "${temp_dir}/${input_file_no_path_or_ext}_black_fill.png"

# White background
convert "${temp_dir}/${input_file_no_path_or_ext}_resized.png" -filter "lanczos" -background "white" -alpha "remove" -alpha "off" "${temp_dir}/${input_file_no_path_or_ext}_white_background.png"
